
export interface AlertLabelModel {
    hasAlert: boolean,
    status : string,
    message : string
}