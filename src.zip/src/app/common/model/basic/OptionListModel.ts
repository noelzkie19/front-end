export interface OptionListModel {
    value: string
    label: string
}
