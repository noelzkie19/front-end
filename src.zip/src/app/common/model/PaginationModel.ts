export interface PaginationModel {
    pageSize: number,
    currentPage: number,
    recordCount: number,
    sortOrder: string,
    sortColumn: string
}