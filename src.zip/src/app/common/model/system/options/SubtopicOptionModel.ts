export interface SubtopicOptionModel {
    subtopicId: string
    subtopicName: string
}