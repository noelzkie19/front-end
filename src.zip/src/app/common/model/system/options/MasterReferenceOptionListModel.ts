export interface MasterReferenceOptionListModel {
    masterReferenceId: number
    masterReferenceParentId: number
    masterReferenceChildName: string
    isParent: boolean
}