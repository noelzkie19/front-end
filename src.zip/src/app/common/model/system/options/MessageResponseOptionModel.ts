export interface MessageResponseOptionModel {
    messageResponseId: string
    messageResponseName: string
}