export interface CountryModel {
    countryId: number
    countryCode: string
    countryName: string
    status: boolean
    createdBy: string
    createdDate: string
    updatedBy: string
    updatedDate: string
}