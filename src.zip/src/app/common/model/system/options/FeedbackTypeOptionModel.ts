export interface FeedbackTypeOptionModel {
    feedbackTypeId: string
    feedbackTypeName: string
}