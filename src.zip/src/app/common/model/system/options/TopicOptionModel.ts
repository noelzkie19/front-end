export interface TopicOptionModel {
    topicId: string
    topicName: string
}