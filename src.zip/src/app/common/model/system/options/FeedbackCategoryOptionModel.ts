export interface FeedbackCategoryOptionModel {
    feedbackCategoryId: string
    feedbackCategoryName: string
}