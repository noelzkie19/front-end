export interface FeedbackAnswerOptionRequestModel {
    feedbackTypeId: string
    feedbackCategoryId: string
    feedbackFilter: string
}