export interface MessageStatusOptionModel {
    messageStatusId: string
    messageStatusName: string
}