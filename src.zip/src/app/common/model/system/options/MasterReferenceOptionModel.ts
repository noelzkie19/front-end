import { OptionListModel } from "../..";

export interface MasterReferenceOptionModel  {
    masterReferenceParentId: number,
    options: OptionListModel
}