export interface FeedbackAnswerOptionModel {
    feedbackAnswerId: string
    feedbackAnswerName: string
    feedbackCategoryId: string
    feedbackCategoryName: string
    feedbackTypeId: string
    feedbackTypeName: string
}