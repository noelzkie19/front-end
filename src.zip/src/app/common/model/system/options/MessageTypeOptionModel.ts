export interface MessageTypeOptionModel {
    messageTypeId: string
    messageTypeName: string
}