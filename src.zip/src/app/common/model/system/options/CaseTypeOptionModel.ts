export interface CaseTypeOptionModel {
    caseTypeId: string
    caseTypeName: string
}