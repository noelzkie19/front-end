export interface UserGridCustomDisplayResponseModel {
    display: string
    isForFilter: boolean
    section: number
}