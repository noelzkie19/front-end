export interface LookupModel {
    label: string
    value?: string
}