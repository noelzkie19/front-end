

var noResultOverlayTemplate = '<span class="ag-overlay-loading-center"><span id="mlab-grid-loading-overlay">No Rows To Show</span></span>'
export default noResultOverlayTemplate;