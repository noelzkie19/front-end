export const gridOverlayNoRowsTemplate = '<span class="ag-overlay-loading-center"><span id="mlab-grid-loading-overlay">No Rows To Show</span></span>';

const gridOverlayTemplate =
	'<span class="ag-overlay-loading-center"><span id="mlab-grid-loading-overlay">Please wait while your items are loading</span></span>';
export default gridOverlayTemplate;
