import { RequestModel } from "../../../system/models";

export interface JourneyDetailsRequestModel extends RequestModel
{
    journeyId: number
};