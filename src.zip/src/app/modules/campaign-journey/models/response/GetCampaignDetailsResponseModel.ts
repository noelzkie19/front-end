export interface GetCampaignDetailsResponseModel {
    campaignId: number,
    campaignName: string,
    campaignStatus: string,
    campaignPlayerCount: number,
    campaignEligibility: string,
    campaignPrimaryGoalCount: number,
    campaignCallListCount: number
}