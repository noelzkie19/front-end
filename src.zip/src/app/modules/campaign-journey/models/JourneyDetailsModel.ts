export interface JourneyDetailsModel {
    journeyId?: number,
    journeyName?: string,
    journeyDescription?: string,
    journeyStatus?: string,
    createdDate?: string,
    createdBy?: string,
    updatedDate?: string,
    updatedBy?: string,
}