export interface AppConfigSettingFilterModel {
	appConfigSettingId: number;
	applicationId?: number;
	key: string;
	value: string;
	dataType: string;
}
