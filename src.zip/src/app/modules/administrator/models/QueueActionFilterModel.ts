export interface QueueActionFilterModel {
    id: number
    action: string
}