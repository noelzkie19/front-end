export interface QueueFilterModel {
    pageSize?: number
    offsetValue?: number
    sortColumn?: string
    sortOrder?: string
    createdBy?: string,
    createdFrom?: string,
    createdTo?: string,
    status?: string,
    action?: string
}