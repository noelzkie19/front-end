export interface EventSubscriptionResponseModel {
    EventSubscriptionId: number;
	EventType: string;
    SubscriberEventTypeId: number;
    SubscriberStatusId: number;
    SubscriberStatus: string;
}
