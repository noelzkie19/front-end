export interface CreatedByFilterModel {
    userId: number
    fullname: string
}