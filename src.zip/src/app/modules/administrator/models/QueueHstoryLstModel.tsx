export interface QueueHstoryLstModel {
    queueId: string,
    queueName: string,
    userId: string,
    createdBy: string,
    createdByUser: string,
    createdDate: string,
    queueStatus: string,
    redisCacheId: string,
    action: string
}