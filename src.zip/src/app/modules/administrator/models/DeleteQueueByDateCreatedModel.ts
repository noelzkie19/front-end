export interface DeleteQueueByDateCreatedModel {
    createdFrom: string,
    createdTo: string,
    userId: string
}