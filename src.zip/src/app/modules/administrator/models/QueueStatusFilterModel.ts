export interface QueueStatusFilterModel {
    id: number
    queueStatus: string
}