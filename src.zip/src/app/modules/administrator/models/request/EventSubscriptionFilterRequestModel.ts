import {RequestModel} from '../../../system/models';

export interface EventSubscriptionFilterRequestModel extends RequestModel {}
