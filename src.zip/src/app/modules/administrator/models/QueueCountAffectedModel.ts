export interface QueueCountAffectedModel {
    totalHstoryRecordCnt: number,
    totalRqstRecordCnt: number
}