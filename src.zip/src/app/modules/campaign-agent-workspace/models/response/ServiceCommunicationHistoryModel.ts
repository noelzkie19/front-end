export interface ServiceCommunicationHistoryModel {
    callListNoteId: number
    campaignPlayerId: number
    note: string
    createdBy: number
    createdByName: string
    createdDate: string
    updatedBy: number
    updatedByName: string
    updatedDate: string
    caseType: string
    caseTypeId: number
} 
