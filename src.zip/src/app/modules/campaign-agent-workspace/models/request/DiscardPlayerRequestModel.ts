export interface DiscardPlayerRequestModel {
    campaignPlayerIds: string,
    userId: number
}