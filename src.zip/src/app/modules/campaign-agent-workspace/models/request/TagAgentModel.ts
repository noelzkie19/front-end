export interface TagAgentModel {
    campaignPlayerId: number
    agentId: number
    userId: string
}