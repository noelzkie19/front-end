import { TagAgentModel } from "./TagAgentModel";

export interface TagAgentRequestModel {
    tagList: Array<TagAgentModel>
}