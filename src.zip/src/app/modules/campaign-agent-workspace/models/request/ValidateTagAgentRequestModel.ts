import { ValidateTagAgentModel } from "./ValidateTagAgentModel";

export interface ValidateTagAgentRequestmodel {
    tagList: Array<ValidateTagAgentModel>
}