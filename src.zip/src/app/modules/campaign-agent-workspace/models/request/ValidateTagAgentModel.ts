export interface ValidateTagAgentModel {
    campaignPlayerId: number
    userId: number
    isLeader: number
}