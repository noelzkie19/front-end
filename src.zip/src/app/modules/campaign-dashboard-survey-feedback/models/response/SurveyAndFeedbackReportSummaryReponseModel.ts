export interface SurveyAndFeedbackReportSummaryReponseModel {
	startDate: string;
	endDate: string;
	campaignReportPeriod: number;
	campaignType: string;
	campaignId: number;
	campaignName: string;
	campaignStatus: string;
	brand: string;
	currency: string;
}
