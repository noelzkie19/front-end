export interface SurveyResultChartModel {
    data1: Array<number>,
    data2: Array<number>,
    category: Array<string>
}