export interface FeedbackResultResponseModel {
    feedbackCategory: string,
    feedbackAnswer: string,
    count: number,
    ftd: number,
    ftdPercentage: number,
    initialDeposit: number,
    initialDepositPercentage: number
}