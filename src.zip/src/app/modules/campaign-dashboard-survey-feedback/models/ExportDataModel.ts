export interface ExportDataModel {
    detail : any,
    sheetName : string,
}