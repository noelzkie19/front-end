export interface AgentFilterResponseModel {
    agentId: number
    agentName: string

}
