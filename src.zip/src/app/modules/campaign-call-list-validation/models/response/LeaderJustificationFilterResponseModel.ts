export interface LeaderJustificationFilterResponseModel {
    leaderJustificationId: number
    justification: string

}
