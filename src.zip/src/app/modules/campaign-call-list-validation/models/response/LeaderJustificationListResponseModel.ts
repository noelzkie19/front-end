export interface LeaderJustificationListResponseModel {
    justification: string
    status: boolean
    leaderJustificationId: number
    createdBy: number
    createdDate: string
    updatedBy: number
    updatedDate: string
}
