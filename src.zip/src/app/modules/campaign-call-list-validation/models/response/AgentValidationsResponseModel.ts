export interface AgentValidationsResponseModel {
    agentValidationId: number
    agentValidationStatus: boolean
    agentValidationNotes: string
    isAgentValidated: boolean
    campaignPlayerId: number
    createdBy: number
    createdDate: string
    updatedBy: number
    updatedDate: string

}