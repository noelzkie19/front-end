export interface CallEvaluationResponseModel {
    callEvaluationId: number
    evaluationPoint: number
    evaluationNotes: string
    campaignPlayerId: number
    createdBy: number
    createdDate: string
    updatedBy: number
    updatedDate: string
}