export interface DeleteCallEvaluationRequestModel {
    queueId: string
    userId: string
    callEvaluationId : number
}