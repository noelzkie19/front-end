export interface LeaderJustificationRequestModel {
    queueId: string
    userId: string
    justification: string
    status: boolean
    createdBy: number
    updatedBy: number
    leaderJustificationId: number
}
