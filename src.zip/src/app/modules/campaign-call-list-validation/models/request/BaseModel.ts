export interface BaseModel {
    queueId: string
    userId: string
}