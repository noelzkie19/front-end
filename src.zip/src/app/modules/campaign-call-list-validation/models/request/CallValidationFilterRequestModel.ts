export interface CallValidationFilterRequestModel {
    campaignId: number
}
