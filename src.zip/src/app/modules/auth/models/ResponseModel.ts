export interface ResponseModel {
    status: number
    message: string
}