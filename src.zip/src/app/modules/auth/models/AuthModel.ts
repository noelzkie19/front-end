export interface AuthModel {
  token: string
  userId: string
  access: string
  expiresIn: string
}
