

export interface TaggingConfigurationModel{
    taggingConfigurationId?: number
    taggingConfigurationName: string
    campaignSettingId?: number
    segmentName: string
    priorityNumber?: number
    segmentId?: number
    // createdBy?: string
    createdDate?: string
    // updatedBy?: string
     updatedDate?: string
     action?: string
}