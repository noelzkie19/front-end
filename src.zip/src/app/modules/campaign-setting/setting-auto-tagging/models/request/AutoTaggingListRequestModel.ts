

export interface AutoTaggingListRequestModel{
    settingId: number,
    settingName: string,
    settingStatus: number,
    settingTypeId: number,
    createdDateTime: string
}