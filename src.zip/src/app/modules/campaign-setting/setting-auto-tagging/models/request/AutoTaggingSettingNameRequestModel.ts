export interface AutoTaggingSettingNameRequestModel {
    campaignSettingName: string,
    campaignSettingTypeId?: number,
    campaignSettingId?: number
}