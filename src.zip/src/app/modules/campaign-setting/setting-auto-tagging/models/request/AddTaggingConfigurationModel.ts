

export interface AddTaggingConfigurationModel{
    taggingConfigurationId?: number
    taggingConfigurationName: string
    campaignSettingId?: number
    segmentName: string
    priorityNumber?: number
    segmentId?: number
    createdBy?: number
    createdDate?: string
    updatedBy?: number
    updatedDate?: string
}