export interface DropdownModel {
    value: string
    label: string
}

