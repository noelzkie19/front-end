export interface UserSelectionModel {
    userId: number
    fullName: string
}