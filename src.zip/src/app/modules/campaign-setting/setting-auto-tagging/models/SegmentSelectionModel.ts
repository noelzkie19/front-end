export interface SegmentSelectionModel {
    segmentId: number
    segmentName: string
}