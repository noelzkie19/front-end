export interface CampaignPeriodDetailsModel{
    campaignId: number,
    campaignSettingId: number,
    campaignName: string,
    campaignStatusId?: number,
    campaignPeriod: string,
    campaignStatus: string,   
}