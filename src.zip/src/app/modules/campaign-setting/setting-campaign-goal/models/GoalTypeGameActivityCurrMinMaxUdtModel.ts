export interface GoalTypeGameActivityCurrMinMaxUdtModel {
	goalTypeGameActivityCurrMinMaxId: number;
	currencyId: number;
	goalTypeGameActivityId: number;
	min: number;
	createdBy: number;
	updatedBy: number;
	goalTypeGuid: string;
}
