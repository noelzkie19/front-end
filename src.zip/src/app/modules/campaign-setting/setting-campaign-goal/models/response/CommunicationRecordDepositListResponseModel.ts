export interface CommunicationRecordDepositListResponseModel {
	campaignSettingId: number;
	createdBy?: number;
	createdDate: string;
	goalTypeCommunicationRecordDepositId: number;
	goalTypeDataSourceName: string;
	goalTypeId?: number;
	goalTypeName: string;
	goalTypePeriodName: string;
	sequenceId?: number;
	sequenceName: string;
	updatedBy?: number;
	updatedDate: string;
}
