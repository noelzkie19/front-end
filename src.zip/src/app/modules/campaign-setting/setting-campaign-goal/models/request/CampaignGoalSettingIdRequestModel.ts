import {BaseRequestModel} from './BaseRequestModel';

export interface CampaignGoalSettingIdRequestModel extends BaseRequestModel {
	campaignSettingId: number;
}
