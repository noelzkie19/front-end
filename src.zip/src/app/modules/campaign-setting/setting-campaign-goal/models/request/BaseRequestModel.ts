export interface BaseRequestModel {
    userId: string
    queueId: string
}