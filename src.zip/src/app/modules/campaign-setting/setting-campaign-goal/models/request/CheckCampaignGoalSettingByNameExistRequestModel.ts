export interface CheckCampaignGoalSettingByNameExistRequestModel {
	CampaignSettingId: number,
	CampaignSettingName: string;
}
