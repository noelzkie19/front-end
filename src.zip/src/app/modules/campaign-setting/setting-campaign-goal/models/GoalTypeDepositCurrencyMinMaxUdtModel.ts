export interface GoalTypeDepositCurrencyMinMaxUdtModel {
	goalTypeDepositCurrencyMinMaxId: number;
	currencyId: number;
	goalTypeDepositId: number;
	min: number;
	max: number;
	createdBy: number;
	updatedBy: number;
	depositGuid: string;
}
