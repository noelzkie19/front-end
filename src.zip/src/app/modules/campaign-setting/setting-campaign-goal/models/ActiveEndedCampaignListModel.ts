export interface ActiveEndedCampaignListModel {
    no: number
    campaignId: number
    campaignName: string
    campaignStatus: string
    campaignReportPeriod: string
}