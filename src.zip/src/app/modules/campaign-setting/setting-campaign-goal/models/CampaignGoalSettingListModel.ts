export interface CampaignGoalSettingListModel{
    campaignSettingId: number
    campaignSettingName: string
    campaignSettingStatus: string
    campaignSettingDescription: string
    goalParameterAmountId: number
    goalParameterAmountName: string
    goalParameterCountId: number
    goalParameterCountName: string
    createdDate: string
    createdBy: number
    updatedDate: string
    updatedBy: number
}