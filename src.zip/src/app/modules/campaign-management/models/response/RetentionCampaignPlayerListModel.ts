export interface RetentionCampaignPlayerListModel 
{
    playerID : string,
    username: string,
    brand: string,
    status: string,
    lastDepositDate: string,
    lastDepositAmount: string,
    bonusAbuser: string,
    lastBetProduct: string,
    lastBetDate: string,
}