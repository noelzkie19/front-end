export interface BotAutoReplyModel {
    botDetailsAutoReplyId:number;
	botDetailId: number;
    telegramBotAutoReplyTriggerId: number;
    trigger: string;
	chatValue: string;
	type: string;
    message: string;
    attachment: string;
}
