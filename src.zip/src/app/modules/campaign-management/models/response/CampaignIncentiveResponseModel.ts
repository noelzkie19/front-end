export interface CampaignIncentiveResponseModel 
{
    campaignIncentiveDataSourceId : number,
    campaignSettingName: string,
    campaignConfigurationId : number,
    campaignSettingId : number,
    amountParameterId :number,
    countParameterId: number,
    sourceTableName: string
}

