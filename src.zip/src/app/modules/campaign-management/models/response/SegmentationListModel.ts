export interface SegmentationListModel 
{
   segmentName: string,
   segmentId : number,
   segmentStatus: boolean,
   varianceId: number,
   varianceName: string
}