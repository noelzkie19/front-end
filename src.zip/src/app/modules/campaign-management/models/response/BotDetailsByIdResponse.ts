export interface BotDetailsByIdResponse{
    botDetailId: number;
    botUsername: string;
	botId: number;
	botToken: string;
	brandId: number;
    botUserId: number;
    statusId: number;
}