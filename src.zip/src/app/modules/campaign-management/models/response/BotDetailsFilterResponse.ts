export interface BotDetailsFilterResponse{
    botDetailId: number;
	botId: number;
    botUsername: string;
	botToken: string;
	brandId: number;
    brand: string;
    botMlabUserId: number;
    botMlabUser: string;
    statusId: number;
    status: string;
}