export interface CampaignUploadPlayerList {
        campaignId: number;
        playerId: number;
        brand: string;
        status: string;
        lastDepositDateFrom: string;
        lastDepositDateTo: string;
        lastDepositAmountFrom: number;
        lastDpeositAmountTo: number;
        bonusAbuser: string;
    }