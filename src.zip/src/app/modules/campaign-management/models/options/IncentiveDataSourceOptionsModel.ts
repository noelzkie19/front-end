export interface IncentiveDataSourceOptionsModel {
    label: string,
    value : string,
    goalParameterAmountId :number,
    goalParameterCountId: number,
    campaignSettingId : string
}
