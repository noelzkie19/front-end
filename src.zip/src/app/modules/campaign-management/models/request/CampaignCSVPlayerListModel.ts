export interface CampaignCSVPlayerListModel{
    playerId: string,
    userName: string,
    brand: string
}