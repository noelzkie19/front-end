import { RequestModel } from "../../../system/models";

export interface BotDetailsFilterRequest extends RequestModel
{
}