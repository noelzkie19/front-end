export interface CampaignLookupByFilterRequestModel {
    campaignId?: number,
    campaignName?: string,
    campaignStatusId?: number,
    campaignTypeId?: number
}