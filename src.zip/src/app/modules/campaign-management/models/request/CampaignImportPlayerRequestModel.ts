import { RequestModel } from "../../../system/models";


export interface CampaignImportPlayerRequestModel extends RequestModel {
    players : string
}