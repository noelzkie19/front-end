export interface ValidatedPlayerListModel {
    validPlayerCount: number;
    invalidPlayerCount: number;
    duplicatePlayerCount: number;
}