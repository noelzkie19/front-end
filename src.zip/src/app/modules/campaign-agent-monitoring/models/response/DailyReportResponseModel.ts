export interface DailyReportResponseModel {
    dailyReportId: number
    campaignAgentId: number
    campaignID: number
    reportDate: string
    shift: string
    hour: number
    minute: number
    second: number
    createdBy: number
    createdDate: string
    updatedBy: number
    updatedDate: string
}
