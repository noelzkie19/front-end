export interface AutoTaggedNameListResponseModel {
    autoTaggedName: string
    autoTaggedId: number
}
