export interface TaggedNameRequestModel {
    campaignId: number
}