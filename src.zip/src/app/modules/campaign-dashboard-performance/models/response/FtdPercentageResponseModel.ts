export interface FtdPercentageResponseModel {
    currency: string,
    ftdYesCount: number,
    totalCallListCount: number,
    ftdPercentage: number
}