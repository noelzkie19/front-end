export interface CampaignActiveAndEndedResponseModel {
    campaignId: number,
    campaignName: string
}