export interface DistributionOfMessagePerCurrencyResponseModel {
    currency: string,
    totalContactableCount: number,
    totalUncontactableCount: number,
    totalInvalidNumberCount: number
}