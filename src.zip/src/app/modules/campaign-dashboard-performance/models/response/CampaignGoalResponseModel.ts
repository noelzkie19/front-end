export interface CampaignGoalResponseModel {
    campaignId: number,
    campaignGoalName: string,
    campaignGoalId: number,
    isPrimary: boolean,
    campaignGoalDesc: string
}