export interface PeConversionListResponseModel {
    currency: string,
    goalReachedPercentage: number,
    goalReachedCount : number,
    totalCallListCount : number,
    totalGoalCount : number,
    totalGoalAmount : number,
    totalGoalAmountInUSD : number

}