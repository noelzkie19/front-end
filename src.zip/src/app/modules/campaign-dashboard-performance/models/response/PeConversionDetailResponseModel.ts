export interface PeConversionDetailResponseModel {
    currency: string
    goalName: string,
    goalDescription: string,
    totalCallListCount: number,
    goalReachedPerCurrency: number
}