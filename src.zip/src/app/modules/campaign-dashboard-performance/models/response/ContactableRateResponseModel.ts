export interface ContactableRateResponseModel {
    currency: string,
    totalContactableCount: number,
    totalCallListCount: number,
    contactablePercentage: number
}